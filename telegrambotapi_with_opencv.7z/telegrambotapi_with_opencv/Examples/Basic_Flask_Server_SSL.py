from flask import Flask ,request
import telegram

# CONFIG
TOKEN               = '98795688:AAFG8cAm6CWB_JJkaDhaLQEqRDkgI4KVW6I'
Telegram_HOST       = 'ynminecraft.noip.me' # Same FQDN used when generating SSL Cert
PORT                = 8443

CERT                = 'cert.pem'
CERT_KEY            = 'private.key'
context             = (CERT, CERT_KEY)

bot = telegram.Bot(TOKEN)
app = Flask(__name__)  #Flask is needed for the webhook



@app.route('/')
def hello_world():
    return 'Hello World!'

@app.route('/' + TOKEN, methods=['POST'])
def webhook():
    update = telegram.update.Update.de_json(request.get_json(force=True)) # Recive the data from the server
    msg = update.message.text.encode('unicode-escape')			# Take the msg part
    print msg	#For Debuging
    if msg == '/start':
        custom_keyboard = [[ telegram.Emoji.THUMBS_UP_SIGN, telegram.Emoji.THUMBS_DOWN_SIGN ]]
        reply_markup = telegram.ReplyKeyboardMarkup(custom_keyboard)
        bot.sendMessage(chat_id=update.message.chat_id, text='Hello, You',reply_markup=reply_markup)
        Master_chat_id = update.message.chat_id
    return 'OK'

def setWebhook():
    bot.setWebhook(webhook_url='https://%s:%s/%s' % (Telegram_HOST, PORT, TOKEN), certificate=open(CERT, 'rb'))


if __name__ == '__main__':
    try:
        # Set the webhook path
        #setWebhook()
        # Run the Flask Server
		app.run(host='0.0.0.0',
				port=PORT,
				ssl_context=context, #when running this command it will config the ssl files
				debug=True)
		print('the program is running')
				
    except Exception as e:
        print("Error: {0}".format(e))
        #traceback.print_exc()
        print ("the program stops")
