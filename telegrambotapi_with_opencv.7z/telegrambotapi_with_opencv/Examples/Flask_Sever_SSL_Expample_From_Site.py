import logging
from telegram.ext import Updater
from telegram.ext import CommandHandler,CallbackQueryHandler
from telegram.ext import MessageHandler, Filters
from telegram.replykeyboardmarkup import ReplyKeyboardMarkup
from telegram import InlineKeyboardButton, InlineKeyboardMarkup

TOKEN = '98795688:AAFG8cAm6CWB_JJkaDhaLQEqRDkgI4KVW6I'
PORT = 8443 

r_m = ReplyKeyboardMarkup([["close","open"]])
i_k = InlineKeyboardButton([["clasdasdasdose","asdasdasdaopen"]])


updater = Updater(token=TOKEN)
dispatcher = updater.dispatcher

inline_number_options_string = "**Please Choose Form That**"
inline_number_options_string_2 = "**Please Choose Form That bla bla bla**"

#Logger
#logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',level=logging.INFO)

def start(bot, update):
	bot.sendMessage(chat_id=update.message.chat_id, text="I'm a bot, please talk to me!")
	print(update.message)
def echo(bot,update):
	bot.sendMessage(chat_id=update.message.chat_id, text=update.message.text)
	print("echo")
def general_run(bot,update):
	if update.message.text == "yon":
		runMe(bot,update)
	else:
		runMe2(bot,update)
def runMe(bot,update):
	keyboard = [[InlineKeyboardButton("Option 1", callback_data='1'),
                 InlineKeyboardButton("Option 2", callback_data='2')],
                [InlineKeyboardButton("Option 3", callback_data='3')]]

	i_k = InlineKeyboardMarkup(keyboard)
	bot.send_message(chat_id=update.message.chat_id, text=inline_number_options_string, reply_markup = i_k)
	print("runme")

def runMe2(bot,update):
	keyboard = [[InlineKeyboardButton("Option__1", callback_data='1'),
                 InlineKeyboardButton("Option__2", callback_data='2')],
                [InlineKeyboardButton("Option__3", callback_data='3')]]

	i_k = InlineKeyboardMarkup(keyboard)
	bot.send_message(chat_id=update.message.chat_id, text=inline_number_options_string_2, reply_markup = i_k)
	print("runme2")
	
#For Handaling the Command /Start
start_handler = CommandHandler('start', start) 
dispatcher.add_handler(start_handler)

blat_handler = MessageHandler(Filters.text, general_run)
dispatcher.add_handler(blat_handler)

echo_handler = MessageHandler(Filters.forwarded , echo)
dispatcher.add_handler(echo_handler)



def button(bot, update):
	query = update.callback_query
	print(query.message.text)
	if (inline_number_options_string == query.message.text):
		print("asdadSA")
		bot.editMessageText(text="Selected option: %s" %query.data,
			chat_id=query.message.chat_id,message_id=query.message.message_id)
	elif (inline_number_options_string_2 == query.message.text):
		bot.editMessageText(text="BLATTT: %s" %query.data,
			chat_id=query.message.chat_id,message_id=query.message.message_id)

updater.dispatcher.add_handler(CallbackQueryHandler(button))


updater.start_polling() #Starting The Bot
