from lxml import html
import requests

# The Data on the train are in "ctl00_PlaceHolderMain_ucTicketWizard_DrivePlanGridUC1_HierarGridSchedule_ctl03_IconshowRow" ctl 02 can be from 0
railPage = requests.get('http://rail.co.il/HE/DrivePlan/Pages/DrivePlan.aspx?DrivePlanPage=true&OriginStationId=7300&DestStationId=8700&HoursDeparture=2&MinutesDeparture=0&GoingHourDeparture=true&GoingHourReturn=true&IsReturn=false&GoingTrainCln=2017-01-25')	



tree = html.fromstring(railPage.content)
#print tree.xpath('//tr/td[@class="GridSortDateItemStyle"]/text()')

#print tree.xpath('//table[@id="ctl00_PlaceHolderMain_ucTicketWizard_DriveTimeScheduler_grdOneWayTrains"]/tr[@class="GridItemStyle"]/td/text()')
#print tree.xpath('//table[@id="ctl00_PlaceHolderMain_ucTicketWizard_DriveTimeScheduler_grdOneWayTrains"]/tr[@class="GridItemStyle" and @class="GridClosestItemStyle"]/td[position()<=6]//text()')
print tree.xpath('//table[@id="ctl00_PlaceHolderMain_ucTicketWizard_DriveTimeScheduler_grdOneWayTrains"]/tr[@class="GridItemStyle"]/td[position()<=6]//text()')


#tr[@class="GridItemStyle"]/text()')

###[position()<=10]/text()')


