#Install package "pip install paho-mqtt"
#Python 2.7
#python c:/Users/Johnny/mqttBase02.py %L;%N;%D
#Example: "Yoni@Shiri;2.Broke.Girls.S06E12.HDTV.x264-LOL[rarbg];D:\Download\uTorrent\TV\Broke Girls\"
import paho.mqtt.client as mqtt
import time #For the Delay
import sys
exit = False;
connected = False;
counter=0;
def on_connection(client, userdata, rc):
    print ("You are connected to the Server")
    client.subscribe("qBitOK")
    connected= True;

def on_message(client, userdata, msg):
    print (msg.topic + " " + str(msg.payload))
#    if msg.payload == "OK":
#       exit = False

print ("Trying connecting to the server")
#mqtt_client = mqtt.Client(client_id="General")
mqtt_client = mqtt.Client()
mqtt_client.on_connect = on_connection
mqtt_client.on_message = on_message
mqtt_client.connect("192.168.1.12",port = 1883, keepalive = 60)
#while(not connected):
#          1

sys.argv.pop(0) 
argumentList = '_'.join(sys.argv).split(';')
print argumentList
if not argumentList[0]:
	argumentList[0] = "Yoni"
msgToSend = ';'.join(argumentList)
print msgToSend 
mqtt_client.publish("qBit",msgToSend )

'''
# Will add next
while((not connected) and (counter < 10)):
	mqtt_client.connect("192.168.1.12",port = 1883, keepalive = 60)
	counter += 1
	time.sleep(10)
counter = 0
while(connected and not(Exit) and (counter < 10)):
	mqtt_client.publish("qBit",msg)#msg[1:]
	counter += 1
	time.sleep(10)	
	#Need to check if i got OK from the server
'''
mqtt_client.disconnect()