#!/usr/bin/env python

'''Using Webhook and self-signed certificate'''

# This file is an annotated example of a webhook based bot for
# telegram. It does not do anything useful, other than provide a quick
# template for whipping up a testbot. Basically, fill in the CONFIG
# section and run it.
# Dependencies (use pip to install them):
# - python-telegram-bot: https://github.com/leandrotoledo/python-telegram-bot
# - Flask              : http://flask.pocoo.org/
# Self-signed SSL certificate (make sure 'Common Name' matches your FQDN):
# $ openssl req -new -x509 -nodes -newkey rsa:1024 -keyout server.key -out server.crt -days 3650
# You can test SSL handshake running this script and trying to connect using wget:
# $ wget -O /dev/null https://$HOST:$PORT/

from flask import Flask, request


from time import strftime
import paho.mqtt.client as mqtt
import telegram
import cv2
import os
# CONFIG
TOKEN    = '98795688:AAFG8cAm6CWB_JJkaDhaLQEqRDkgI4KVW6I'
HOST     = 'ynminecraft.noip.me' # Same FQDN used when generating SSL Cert
PORT     = 8443
CERT     = './ynminecraft.noip.me.cert'
CERT_KEY = './ynminecraft.noip.me.key'
counter = 1
bot = telegram.Bot(TOKEN)
app = Flask(__name__)
context = (CERT, CERT_KEY)
camera_port = 0


#i don't know way but i get two msg
double_msg = "text"

#set mqtt client configure
''' mqtt '''
def on_connection(client, userdata, rc):
    print ("You are connected to the Server")
    client.subscribe("Telegram")
    client.subscribe("qBit")#get data from the turrent
    client.subscribe("router_Send")#get data from the router

def on_message(client, userdata, msg):
	#global double_msg
#newMsg=(msg.topic + " " + str(msg.payload))	#For Debug
    #print(newMsg)
    newMsg=(str(msg.payload))
    if msg.topic == "qBit": #new File has been download
        msgList = newMsg.split(';')
        msgToSend = ('New Download: ' + msgList[1] + ' Path: ' + msgList[2] + ' Label: ' + msgList[0])
        #bot.sendMessage(chat_id=55921881,text=msgToSend)
        print newMsg
        if msgList[0] == 'Yoni' or msgList[0] == 'Yoni@Shiri':
            bot.sendMessage(chat_id=55921881,text=msgToSend)
        if msgList[0] == 'Shiri' or msgList[0] == 'Yoni@Shiri':
            bot.sendMessage(chat_id=63665019,text=msgToSend)
    elif msg.topic == "router_Send":
        bot.sendMessage(chat_id=55921881,text="The Device that connect to the Wifi is:\n" + newMsg)


def write_On_Picture(image, x,y,text):
    white = (255,255,255)
    sky_Blue = (250,206,135)
    black = (0,0,0)
    cv2.putText(image, text ,org=(x,y),fontFace = cv2.FONT_HERSHEY_COMPLEX,fontScale=0.7, color=black , thickness=8,lineType=cv2.CV_AA)
    cv2.putText(image, text ,org=(x,y),fontFace = cv2.FONT_HERSHEY_COMPLEX,fontScale= 0.7,color= sky_Blue,thickness=2,lineType=cv2.CV_AA)

def take_A_Picture(keyboard):
    bot.sendMessage(chat_id=55921881, text="Taking a Picture, Please Wait",reply_markup=keyboard)
    camera = cv2.VideoCapture(camera_port)
    if camera.isOpened():
	#tempaa = camera.set(cv2.CV_CAP_PROP_BRIGHTNESS,60) 
	#print "this is the test" + CV_CAP_PROP_BRIGHTNESS
        camera.set(3,1280)
	camera.set(4,720)
	camera.set(10,10)
	camera.set(10,1) #britness
	#camera.set(15,0.1)
	return_value, image = camera.read()
	dateText=strftime("%Y-%m-%d %H:%M:%S")
	write_On_Picture(image, 10,25, dateText)
	cv2.imwrite("opencv.png", image)
	picture_Size = os.stat('opencv.png').st_size/1024
	write_On_Picture(image, 50,50, str(picture_Size)+'kB')
	cv2.imwrite("opencv.png", image)

	bot.sendChatAction(chat_id=55921881, action=telegram.ChatAction.UPLOAD_PHOTO)
	bot.sendPhoto(chat_id=55921881, photo=open('opencv.png','rb'))
    else:
        msg = "There is A problem with the camera"
	print msg
        bot.sendMessage(chat_id=55921881, text=msg)#,reply_markup=replay_markup)
    del(camera)  # so that others can use the camera as soon as possible
      
  

@app.route('/')
def hello():
    return 'Hello World!'

@app.route('/' + TOKEN, methods=['POST'])
def webhook():
    update = telegram.update.Update.de_json(request.get_json(force=True))
    msg = update.message.text.encode('unicode-escape')
    #custom_keyboard = [[ telegram.Emoji.THUMBS_UP_SIGN, telegram.Emoji.THUMBS_DOWN_SIGN ]]
    custom_keyboard = [[ "close", "open"],[ "picture" ],["Who Is Home"]]
    reply_markup = telegram.ReplyKeyboardMarkup(custom_keyboard, resize_keyboard=True)
    print msg
    if update.message.chat_id == 55921881:
        if msg == "open":
            #bot.sendMessage(chat_id=55921881, text='Hi Yoni Please Enter the Password',reply_markup=telegram.ReplyKeyboardHide())
	    bot.sendMessage(chat_id=55921881, text='The Door Will be Open')#,reply_markup=replay_markup)
        #elif msg == "\U0001f346\U0001f346\U0001f346":
            #bot.sendMessage(chat_id=55921881, text='The Password Is corrected The Door Will be open',reply_markup=reply_markup)
            mqtt_client.publish("escaperoom/piston","1 - The Door Will Be Open")
            print ("The door will be open")
        elif msg == "close":
            bot.sendMessage(chat_id=55921881, text="The Door Will Be Close",reply_markup=reply_markup)
            mqtt_client.publish("escaperoom/piston","0 - The Door Will Be Close")
            print ("The door will be close")
        elif msg == "picture":
	    take_A_Picture(reply_markup)
	elif msg == "Who Is Home":
	    mqtt_client.publish("router_Recive","Who Is Home")
        else:
            bot.sendMessage(chat_id=update.message.chat_id, text='Sorry But i don\'t understand you',reply_markup=reply_markup)
    else:
        bot.sendMessage(chat_id=update.message.chat_id, text='I Don\'t know please leave me alone',reply_markup=reply_markup)#ReplyKeyboardHide())
	print update.message.chat_id
    return 'OK'

def setWebhook():
    bot.setWebhook(webhook_url='https://%s:%s/%s' % (HOST, PORT, TOKEN),
                    certificate=open(CERT, 'rb'))
                #certificate=open(CERT, 'rb'))

if __name__ == '__main__':
    mqtt_client = mqtt.Client()#(client_id="Telegram Bot")
    mqtt_client.on_connect = on_connection
    mqtt_client.on_message = on_message
    #mqtt_clientconnect("localhost",port = 1883, keepalive = 60)
    mqtt_client.connect("192.168.1.101",port = 1883, keepalive = 60)
    #mqtt_client.publish("esp","i am in")
    mqtt_client.loop_start()
    setWebhook()


    app.run(host='0.0.0.0',
            port=PORT,
            ssl_context=context,
            debug=False)
