#!/bin/bash
clear

echo "The Server will be shoutdown"

ps aux | grep python | grep -v "grep python" | awk '{print $2}' | xargs kill -9
sudo lsof -i :8443
