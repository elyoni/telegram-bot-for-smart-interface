import paho.mqtt.client as mqtt #Mqtt client

class TelegramTorrent:
	def __init__(self,hostIP):
		self.client = mqtt.Client()
		self.client.on_connect = self.on_connect
#		self.client.on_message = self.on_message
		self.client.connect(hostIP,1883,60)
		print("on")
		self.client.loop_forever()
	def on_connect(self,client,userdata,flags,rc):
		print("We Are Connected")

TelegramTorrent("127.0.0.1")
