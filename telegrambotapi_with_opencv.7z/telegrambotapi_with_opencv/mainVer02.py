#For the telegram lib
from telegram.ext import Updater
from telegram.ext import CommandHandler,CallbackQueryHandler
from telegram.ext import MessageHandler, Filters
from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from telegram.inlinekeyboardbutton import InlineKeyboardButton
import telegram

from lxml import html
import requests


#For mqtt
import paho.mqtt.client as mqtt


class TelegramServer:
	def __init__(self):
		openFiles = open('permission.ini','r').readlines()
		self.permissionsList = [i.replace('\n','').split(' ',2) for i in openFiles] #To Remove the \n in the test
		self.admin_user_data = filter(lambda x: 'admin' in x, self.permissionsList)[0]
		print "The admin user is " + ' '.join(self.admin_user_data)
		self.railBot = IsraelRailBot()
		self.telegram_server_configure() #Connect To Telegram Server
		self.mqtt_server_configure()

	def telegram_server_configure(self):
		self.PORT = 8443
		self.TOKEN = '98795688:AAFG8cAm6CWB_JJkaDhaLQEqRDkgI4KVW6I'
		updater = Updater(token=self.TOKEN)
		self.bot = telegram.Bot(self.TOKEN)
				##Functions Configure
		self.dispatcher = updater.dispatcher
		self.dispatcher.add_handler(CommandHandler('start', self.start))
		self.dispatcher.add_handler(CommandHandler('rail', self.rail))
		self.dispatcher.add_handler(CallbackQueryHandler(self.button))		

		updater.start_polling()		

	def mqtt_server_configure(self):
		self.mqtt_client = mqtt.Client()#(client_id="Telegram Bot")
		self.mqtt_client.on_connect = self.on_connection
		self.mqtt_client.on_message = self.on_message
		self.mqtt_client.connect("127.0.0.1",port = 1883, keepalive = 60)
		self.mqtt_client.publish("debug","connected to the server")
		self.mqtt_client.loop_start()
	
	#def on_connection(self,client, userdata, rc):
	def on_connection(self, client, obj, flags, rc):
	    print ("You are connected to the Server")
	    client.subscribe("Telegram")
	    client.subscribe("qBit")#get data from the turrent
	    client.subscribe("router_Send")#get data from the router
	def on_message(self,client, userdata, msg):
		newMsg=(str(msg.payload))
		print newMsg
		if msg.topic == "qBit":
			msgList = newMsg.split(';')
			msgToSend = ('New Download:  ' + msgList[1] + ', Path: ' + msgList[2] + ', Label: ' + msgList[0])
			for user in msgList[0].split('@'):
				print user
				try:
					userID = filter(lambda x: user in x, self.permissionsList)[0][2]
					self.bot.sendMessage(chat_id=userID,text=msgToSend,reply_markup=telegram.ReplyKeyboardRemove())
				except:
					unknownUser =  "The User " + user + " Is unknown sending message to admin"
					print unknownUser
					msgToSendTemp =  unknownUser + "\n" + msgToSend
					self.bot.sendMessage(chat_id=self.admin_user_data[2],text=msgToSendTemp,reply_markup=telegram.ReplyKeyboardRemove())
				
	def start(self,bot, update):
		update.message
		bot.sendMessage(chat_id=update.message.chat_id, text="_*Hi my Friend*_ `codeblock`", parse_mode="markdown")
		match_user = filter(lambda x: str(update.message.from_user.id) in x, self.permissionsList)
		if match_user != []:
			print "Every Thing Is ok i know the user"
			update.message.reply_text('HI How Are You')
		else:
			print self.admin_user_data[2]
			bot.send_message(chat_id = self.admin_user_data[2], text = "An unauthorized account send a /start command to the bot.\n The accound data is:\n" + str(update.message.from_user))
			print "An unauthorized account send a /start command to the bot.\n The accound data is"	+ str(update.message.from_user) 
			#add a list of option what to do with the user data
	def rail(self,bot,update):
		update.message.reply_text("Choose Your Start Station", reply_markup = self.railBot.get_station_keyboard())
	
	def button(self,bot, update):
		query = update.callback_query
		print(query.message.text)
		# Rail queue
		if ("Choose Your Start Station" == query.message.text):
			print ("I Am wating for stop Station")
			#print query.message
			self.railBot.set_start_station(query.data)
			bot.editMessageText(text="Thanks",chat_id=query.message.chat_id,message_id=query.message.message_id)
			bot.sendMessage(chat_id=query.message.chat_id,text="Choose Your Stop Station",reply_markup=self.railBot.get_station_keyboard())
			#update.message.reply_text("Choose Your Stop Station", reply_markup = self.railBot.get_keyboard())

		elif ("Choose Your Stop Station" == query.message.text):
			print ("I am waiting for time sation")
			self.railBot.set_stop_station(query.data)
			bot.editMessageText(text="Thanks",chat_id=query.message.chat_id,message_id=query.message.message_id)		
			bot.sendMessage(chat_id=query.message.chat_id,text="Choose The Time You Want To Get on the Train",reply_markup=self.railBot.get_hours_keyboard())

		elif ("Choose The Time You Want To Get on the Train" == query.message.text):
			print("Done, Now I need to send the data to the site and parser the data into a text table")
				

#update.callback_query.message.edit_text(text="Test",chat_id=query.message.chat_id,message_id=query.message.message_id)
#elif (inline_number_options_string_2 == query.message.text):
#			bot.editMessageText(text="BLATTT: %s" %query.data,
#				chat_id=query.message.chat_id,message_id=query.message.message_id)
class IsraelRailBot:
	def __init__(self):
		self.stationNames = list() #i Usethem But i dont think that i need them
		self.stationNumber = list()#i Usethem But i dont think that i need them
		self.stationKeyboard = list()
		self.hoursKeyboard = list()
		self.startStation = int()
		self.stopStation = int()
		self.create_station_keyboard()
		self.create_hours_list()
		print "Israel Rail Bot Has Been Created"

	def create_station_keyboard(self):
		railPage = requests.get('http://rail.co.il/')
		tree = html.fromstring(railPage.content)
		self.stationNames = tree.xpath('//select[@id="ctl00_PlaceHolderMain_ucSmallDrivePlan_cmbOriginStation"]/option/text()')
		self.stationNumbers = tree.xpath('//select[@id="ctl00_PlaceHolderMain_ucSmallDrivePlan_cmbOriginStation"]/option/@value')
		# Taking the First element out off the list, there are empty
		self.stationNames.pop(0)
		self.stationNumbers.pop(0)
		for stationName,stationNumber in zip(self.stationNames,self.stationNumbers):
			self.stationKeyboard.append(InlineKeyboardButton(stationName, callback_data=stationNumber))
		self.stationKeyboard = [self.stationKeyboard[x:x+2] for x in range(0,len(self.stationKeyboard),2)] #Cut the list into group of 2
	def create_hours_list(self):
		hoursList =  ['00:00','1:00','2:00','3:00','4:00','5:00','6:00','7:00','8:00','9:00','10:00','11:00','12:00','13:00','14:00','15:00','16:00','17:00','18:00','19:00','20:00','21:00','22:00','23:00']
		for hourElement in hoursList:
			self.hoursKeyboard.append(InlineKeyboardButton(hourElement, callback_data=hourElement))
		self.hoursKeyboard = [self.hoursKeyboard[x:x+6] for x in range(0,len(self.hoursKeyboard),6)]

	def get_hours_keyboard(self):
		return InlineKeyboardMarkup(self.hoursKeyboard)

	def get_station_keyboard(self):
		print "Returning The Keyboard Set For Sending as keyboard object"
		return InlineKeyboardMarkup(self.stationKeyboard)

	def set_start_station(self, stationNumber):
		self.startStation = stationNumber

	def set_stop_station(self, stationNumber):
		self.stopStation = stationNumber
	
	
def enterNewAccount(bot,update):
	print("Look at the list and see who is in")

telegramserver = TelegramServer()
#def torrent(bot,update):
	#keyboard=[[InlineKeyboardButton("Yoni's List",callback_date='yoni'),InlineKeyboardButton("Shiri's List",callback_date='shiri'),InlineKeyboardButton("General's List",callback_date='general')

#bot.editMessageReplyMarkup(reply_markup=InlineKeyboardMarkup(keyboardTemp),chat_id=query.message.chat_id,message_id=query.message.message_id)

